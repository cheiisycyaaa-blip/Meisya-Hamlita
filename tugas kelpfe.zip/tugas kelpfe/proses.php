<?php
$nama = $_POST['nama'];
$lab = $_POST['lab'];
$gangguan = $_POST['gangguan'];
$keterangan = $_POST['keterangan'];
echo "<h2>Laporan Gangguan Jaringan</h2>";
echo "Nama Pelapor : $nama <br>";
echo "Laboratorium : $lab <br>";
echo "Jenis Gangguan : $gangguan <br>";
echo "Keterangan : $keterangan <br>";
?>