function validasi() {
    var nama = document.getElementById("nama").value;
    var lab = document.getElementById("lab").value;
    var gangguan = document.getElementById("gangguan").value;
    if (nama === "" || lab === "" || gangguan === "") {
        alert("Semua field wajib diisi!");
        return false;
    }
    return true;
}